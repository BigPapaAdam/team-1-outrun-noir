﻿public class GameManager
{
    public bool Fullscreen;
    public int ResolutionIndex;
    public float MusicVolume;
    public float SFXVolume;

    public bool FullScreen
    {
        get
        {
            return Fullscreen;
        }

        set
        {
            Fullscreen = value;
        }
    }

    public int Resolutionindex
    {
        get
        {
            return ResolutionIndex;
        }

        set
        {
            ResolutionIndex = value;
        }
    }

    public float Musicvolume
    {
        get
        {
            return MusicVolume;
        }

        set
        {
            MusicVolume = value;
        }
    }

    public float SFXvolume
    {
        get
        {
            return SFXVolume;
        }

        set
        {
            SFXVolume = value;
        }
    }
}
